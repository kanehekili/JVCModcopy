JVC MODs are converted into mp2 videos, setting the correct pixel aspect ratio.
the libmc code has been take from #Andreas Balogh
This is a GTK3 app, so no tkinter is used.
